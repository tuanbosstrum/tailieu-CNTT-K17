
function validate() {
var u = document.getElementById("username").value;
var p1 = document.getElementById("password").value;
var p2 = document.getElementById("password-repeat").value;
  
if(u== "") {
alert("Vui lòng nhập tên!");
return false;
}
if((p1 == "")|| (p1.length<6)) {
alert("Vui lòng nhập mật khẩu!");
return false;
}
if(p2 == "") {
alert("Vui lòng xác minh mật khẩu!");
return false;
}
if ((u!="") &&( p1==p2)) {//dnhap.usn=u;dnhap.pw=p1;dnhap.cp=p2;
 alert("bạn đã đăng ký thành công");}
else  
alert("Xin hãy điền đúng thông tin!")
  
return true;
}
function validate1() {
var uu = document.getElementById("username1").value;
var pu1 = document.getElementById("password1").value;
if(uu== "") {
alert("Vui lòng nhập tên!");
return false;
}
if(pu1 == "") {
alert("Vui lòng nhập mật khẩu!");
return false;
}
if((uu=="abc")&&(pu1="123"))alert("bạn đã đăng nhập thành công");
else  
alert("Bạn hãy đăng nhập lại!")
  
return true;
}